﻿namespace FinalOOp.Model
{
    public class Admin
    {
        public int AdminId { get; set; }  // Unique identifier for Admin
        public string Username { get; set; } // Username for login purposes
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Email { get; set; }
        public string Password { get; set; }
        public string Role { get; set; }

    }
}
