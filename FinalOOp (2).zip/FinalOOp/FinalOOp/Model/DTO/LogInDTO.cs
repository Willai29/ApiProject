﻿namespace FinalOOp.Model.DTO
{
    public class LoginDto
    {
        public string Username { get; set; }   // Add Username property
        public string Password { get; set; }   // Password property already exists
        public string Platform { get; set; }   // Add Platform property
    }
}
