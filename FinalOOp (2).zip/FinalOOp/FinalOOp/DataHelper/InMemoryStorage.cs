﻿using FinalOOp.Model;

namespace FinalOOp.DataHelper
{
    public static class InMemoryStorage
    {
        // Salt for hashing
        public static string Salt = ")GN#447#^nryrETNwrbR%#&NBRE%#%BBDT#%";

        // Lists to store Admins, Products, and Orders
        public static List<Product> Products = new List<Product>(); // List for storing products
        public static List<Admin> Admins = new List<Admin>
        {
            new Admin
            {
                AdminId = 1,
                Username = "admin",
                FirstName = "Mark",
                LastName = "Pasco",
                Email = "mark.pasco@example.com",
                Password = "dde6a80ee27ed148c86020e2cfaf6d28", // Hashed password
            },
            new Admin
            {
                AdminId = 2,
                Username = "sarah_lee",
                FirstName = "Sarah",
                LastName = "Lee",
                Email = "sarah.lee@example.com",
                Password = "6cb75f652a9b52798eb6cf2201057c73", // Hashed password
            }
        };

        // Orders List to store orders
        public static List<Order> Orders = new List<Order>
        {
            new Order
            {
                OrderId = 1,
                OrderDate = DateTime.Now.AddDays(-5), // Example past date
                CustomerId = 1,
                TotalAmount = 1250.00m, // Example total amount
            },
            new Order
            {
                OrderId = 2,
                OrderDate = DateTime.Now.AddDays(-3), // Example past date
                CustomerId = 2,
                TotalAmount = 350.00m, // Example total amount
            }
        };
        // Static constructor to initialize product and order data
        static InMemoryStorage()
        {
            // Seed Products
            Products.Add(new Product { Id = 101, Name = "Laptop", Price = 1200, Description = "High-performance laptop", Stock = 5 });
            Products.Add(new Product { Id = 102, Name = "Keyboard", Price = 50, Description = "Mechanical keyboard", Stock = 10 });
            Products.Add(new Product { Id = 103, Name = "Mouse", Price = 25, Description = "Wireless mouse", Stock = 15 });
            Products.Add(new Product { Id = 104, Name = "Monitor", Price = 300, Description = "27-inch monitor", Stock = 8 });

            // Seed Orders
            Orders.Add(new Order
            {
                OrderId = 1,
                OrderDate = DateTime.Now.AddDays(-5), // Example past date
                CustomerId = 1,
                TotalAmount = 1250.00m, // Example total amount
            });
            Orders.Add(new Order
            {
                OrderId = 2,
                OrderDate = DateTime.Now.AddDays(-3), // Example past date
                CustomerId = 2,
                TotalAmount = 350.00m, // Example total amount
            });
            Orders.Add(new Order
            {
                OrderId = 3,
                OrderDate = DateTime.Now.AddDays(-10), // Example past date
                CustomerId = 3,
                TotalAmount = 450.00m, // Example total amount
            });
            Orders.Add(new Order
            {
                OrderId = 4,
                OrderDate = DateTime.Now.AddDays(-7), // Example past date
                CustomerId = 4,
                TotalAmount = 800.00m, // Example total amount
            });
        }
    }
}