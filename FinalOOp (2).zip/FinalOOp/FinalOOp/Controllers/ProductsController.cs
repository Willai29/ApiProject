﻿using FinalOOp.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;

namespace FinalOOp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ProductsController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public ProductsController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        private string ConnectionString => _configuration.GetConnectionString("DefaultConnection");

        [HttpGet("GetAllProducts")]
        [AllowAnonymous]
        public IActionResult GetAllProducts()
        {
            var products = ExecuteReader("SELECT * FROM Products", MapReaderToProduct);
            if (products == null || products.Count == 0)
                return NotFound(new { Message = "No products found." });

            return Ok(products);
        }

        [HttpPost("AddProduct")]
        [Authorize]
        public IActionResult AddProduct([FromBody] Product product)
        {
            if (product == null || string.IsNullOrWhiteSpace(product.Name) || product.Price <= 0)
            {
                return BadRequest(new { message = "Invalid product data." });
            }

            try
            {
                string query = @"
                    INSERT INTO Products (Name, Price, Description, Stock)
                    VALUES (@Name, @Price, @Description, @Stock)";
                var parameters = new Dictionary<string, object>
                {
                    { "@Name", product.Name },
                    { "@Price", product.Price },
                    { "@Description", product.Description},
                    { "@Stock", product.Stock }
                };

                if (ExecuteNonQuery(query, parameters))
                    return Ok(new { message = "Product added successfully." });

                return StatusCode(500, new { message = "Failed to add product." });
            }
            catch (Exception ex)
            {
                return StatusCode(500, new { message = "An error occurred while adding the product.", error = ex.Message });
            }
        }

        [HttpPut("UpdateProduct/{id}")]
        [Authorize]
        public IActionResult UpdateProduct(int id, [FromBody] Product updatedProduct)
        {
            if (!ModelState.IsValid)
                return BadRequest(new { Message = "Invalid product data." });

            string query = "UPDATE Products SET Name = @Name, Price = @Price, Description = @Description, Stock = @Stock WHERE Id = @Id";
            var parameters = new Dictionary<string, object>
            {
                { "@Id", id },
                { "@Name", updatedProduct.Name },
                { "@Price", updatedProduct.Price },
                { "@Description", updatedProduct.Description },
                { "@Stock", updatedProduct.Stock }
            };

            if (ExecuteNonQuery(query, parameters))
                return Ok(new { Message = "Product updated successfully." });

            return NotFound(new { Message = "Product not found." });
        }

        [HttpDelete("DeleteProduct/{id}")]
        [Authorize]
        public IActionResult DeleteProduct(int id)
        {
            string query = "DELETE FROM Products WHERE Id = @Id";
            var parameters = new Dictionary<string, object> { { "@Id", id } };

            if (ExecuteNonQuery(query, parameters))
                return Ok(new { Message = "Product deleted successfully." });

            return NotFound(new { Message = "Product not found." });
        }

        [HttpGet("GetProduct/{id}")]
        [Authorize]
        public IActionResult GetProduct(int id)
        {
            string query = "SELECT * FROM Products WHERE Id = @Id";
            var parameters = new Dictionary<string, object> { { "@Id", id } };

            var product = ExecuteReader(query, MapReaderToProduct, parameters).FirstOrDefault();
            if (product == null)
                return NotFound(new { Message = "Product not found." });

            return Ok(product);
        }

        // Helper Methods
        private bool ExecuteNonQuery(string query, Dictionary<string, object> parameters)
        {
            using var connection = new MySqlConnection(ConnectionString);
            connection.Open();

            using var command = new MySqlCommand(query, connection);
            foreach (var param in parameters)
                command.Parameters.AddWithValue(param.Key, param.Value);

            return command.ExecuteNonQuery() > 0;
        }

        private List<T> ExecuteReader<T>(string query, Func<MySqlDataReader, T> map, Dictionary<string, object> parameters = null)
        {
            var results = new List<T>();
            using var connection = new MySqlConnection(ConnectionString);
            connection.Open();

            using var command = new MySqlCommand(query, connection);
            if (parameters != null)
            {
                foreach (var param in parameters)
                    command.Parameters.AddWithValue(param.Key, param.Value);
            }

            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                results.Add(map(reader));
            }

            return results;
        }

        private Product MapReaderToProduct(MySqlDataReader reader)
        {
            return new Product
            {
                Id = reader.GetInt32("Id"),
                Name = reader.GetString("Name"),
                Price = reader.GetDecimal("Price"),
                Description = reader.IsDBNull(reader.GetOrdinal("Description")) ? null : reader.GetString("Description"),
                Stock = reader.GetInt32("Stock")
            };
        }
    }
}
