﻿using FinalOOp.Model;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;

namespace FinalOOp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class OrderController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public OrderController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        private string ConnectionString => _configuration.GetConnectionString("DefaultConnection");

        [HttpGet("GetAllOrders")]
        [AllowAnonymous]
        public IActionResult GetAllOrders()
        {
            var orders = ExecuteReader("SELECT * FROM Orders", MapReaderToOrder);
            if (orders == null || orders.Count == 0)
                return NotFound(new { Message = "No orders found." });

            return Ok(orders);
        }

        [HttpPost("CreateOrder")]
        [Authorize]
        public IActionResult CreateOrder([FromBody] Order order)
        {
            if (order == null || order.TotalAmount <= 0 || order.CustomerId <= 0)
            {
                return BadRequest(new { Message = "Invalid order data." });
            }

            using var connection = new MySqlConnection(ConnectionString);
            connection.Open();
            using var transaction = connection.BeginTransaction();

            try
            {
                // Step 1: Insert the order
                string insertOrderQuery = @"
            INSERT INTO Orders (OrderDate, CustomerId, TotalAmount)
            VALUES (@OrderDate, @CustomerId, @TotalAmount)";
                using var insertOrderCommand = new MySqlCommand(insertOrderQuery, connection, transaction);
                insertOrderCommand.Parameters.AddWithValue("@OrderDate", order.OrderDate);
                insertOrderCommand.Parameters.AddWithValue("@CustomerId", order.CustomerId);
                insertOrderCommand.Parameters.AddWithValue("@TotalAmount", order.TotalAmount);
                insertOrderCommand.ExecuteNonQuery();

                long orderId = insertOrderCommand.LastInsertedId;

                // Step 2: Insert order items and update stock
                foreach (var item in order.OrderItems)
                {
                    // Check stock availability
                    string checkStockQuery = "SELECT Stock FROM Products WHERE Id = @ProductId";
                    using var checkStockCommand = new MySqlCommand(checkStockQuery, connection, transaction);
                    checkStockCommand.Parameters.AddWithValue("@ProductId", item.ProductId);

                    var stock = Convert.ToInt32(checkStockCommand.ExecuteScalar());
                    if (stock < item.Quantity)
                    {
                        transaction.Rollback();
                        return BadRequest(new { Message = $"Insufficient stock for product ID {item.ProductId}." });
                    }

                    // Deduct stock
                    string updateStockQuery = "UPDATE Products SET Stock = Stock - @Quantity WHERE Id = @ProductId";
                    using var updateStockCommand = new MySqlCommand(updateStockQuery, connection, transaction);
                    updateStockCommand.Parameters.AddWithValue("@Quantity", item.Quantity);
                    updateStockCommand.Parameters.AddWithValue("@ProductId", item.ProductId);
                    updateStockCommand.ExecuteNonQuery();

                    // Insert order item
                    string insertOrderItemQuery = @"
                INSERT INTO OrderItems (OrderId, ProductId, Quantity, Price)
                VALUES (@OrderId, @ProductId, @Quantity, @Price)";
                    using var insertOrderItemCommand = new MySqlCommand(insertOrderItemQuery, connection, transaction);
                    insertOrderItemCommand.Parameters.AddWithValue("@OrderId", orderId);
                    insertOrderItemCommand.Parameters.AddWithValue("@ProductId", item.ProductId);
                    insertOrderItemCommand.Parameters.AddWithValue("@Quantity", item.Quantity);
                    insertOrderItemCommand.Parameters.AddWithValue("@Price", item.Price);
                    insertOrderItemCommand.ExecuteNonQuery();
                }

                transaction.Commit();

                return Ok(new { Message = "Order created successfully.", OrderId = orderId });
            }
            catch (Exception ex)
            {
                transaction.Rollback();
                return StatusCode(500, new { Message = "An error occurred while creating the order.", Error = ex.Message });
            }
        }
        [HttpPut("UpdateOrder/{id}")]
        [Authorize]
        public IActionResult UpdateOrder(int id, [FromBody] Order updatedOrder)
        {
            if (!ModelState.IsValid)
                return BadRequest(new { Message = "Invalid order data." });

            string query = "UPDATE Orders SET OrderDate = @OrderDate, CustomerId = @CustomerId, TotalAmount = @TotalAmount WHERE OrderId = @Id";
            var parameters = new Dictionary<string, object>
            {
                { "@Id", id },
                { "@OrderDate", updatedOrder.OrderDate },
                { "@CustomerId", updatedOrder.CustomerId },
                { "@TotalAmount", updatedOrder.TotalAmount }
            };

            if (ExecuteNonQuery(query, parameters))
                return Ok(new { Message = "Order updated successfully." });

            return NotFound(new { Message = "Order not found." });
        }

        [HttpDelete("DeleteOrder/{id}")]
        [Authorize]
        public IActionResult DeleteOrder(int id)
        {
            string query = "DELETE FROM Orders WHERE OrderId = @Id";
            var parameters = new Dictionary<string, object> { { "@Id", id } };

            if (ExecuteNonQuery(query, parameters))
                return Ok(new { Message = "Order deleted successfully." });

            return NotFound(new { Message = "Order not found." });
        }

        [HttpGet("GetOrder/{id}")]
        [Authorize]
        public IActionResult GetOrder(int id)
        {
            string query = "SELECT * FROM Orders WHERE OrderId = @Id";
            var parameters = new Dictionary<string, object> { { "@Id", id } };

            var order = ExecuteReader(query, MapReaderToOrder, parameters).FirstOrDefault();
            if (order == null)
                return NotFound(new { Message = "Order not found." });

            return Ok(order);
        }

        // Helper Methods
        private bool ExecuteNonQuery(string query, Dictionary<string, object> parameters)
        {
            using var connection = new MySqlConnection(ConnectionString);
            connection.Open();

            using var command = new MySqlCommand(query, connection);
            foreach (var param in parameters)
                command.Parameters.AddWithValue(param.Key, param.Value);

            return command.ExecuteNonQuery() > 0;
        }

        private List<T> ExecuteReader<T>(string query, Func<MySqlDataReader, T> map, Dictionary<string, object> parameters = null)
        {
            var results = new List<T>();
            using var connection = new MySqlConnection(ConnectionString);
            connection.Open();

            using var command = new MySqlCommand(query, connection);
            if (parameters != null)
            {
                foreach (var param in parameters)
                    command.Parameters.AddWithValue(param.Key, param.Value);
            }

            using var reader = command.ExecuteReader();
            while (reader.Read())
            {
                results.Add(map(reader));
            }

            return results;
        }

        private Order MapReaderToOrder(MySqlDataReader reader)
        {
            return new Order
            {
                OrderId = reader.GetInt32("OrderId"),
                OrderDate = reader.GetDateTime("OrderDate"),
                CustomerId = reader.GetInt32("CustomerId"),
                TotalAmount = reader.GetDecimal("TotalAmount")
            };
        }
    }
}
