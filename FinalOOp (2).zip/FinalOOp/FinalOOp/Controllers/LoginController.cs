﻿using FinalOOp.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace FinalOOp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LoginController : ControllerBase
    {
        [AllowAnonymous]
        [HttpPost("login")]
        public IActionResult Login([FromBody] LoginRequest request)
        {
            // Example: Hardcoded user validation for demonstration purposes
            if (request.Username == "admin" && request.Password == "password")
            {
                // Create claims for the JWT token
                var claims = new[]
                {
                    new Claim(JwtRegisteredClaimNames.Sub, request.Username),
                    new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
                };

                // Create signing credentials
                var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes("YourSecretKeyHere"));
                var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

                // Set token expiration time
                var expires = DateTime.Now.AddMinutes(60);

                // Create the JWT token
                var token = new JwtSecurityToken(
                    issuer: "YourIssuer",
                    audience: "YourAudience",
                    claims: claims,
                    expires: expires,
                    signingCredentials: creds
                );

                // Return the JWT token
                return Ok(new
                {
                    token = new JwtSecurityTokenHandler().WriteToken(token),
                    expiration = expires
                });
            }

            return Unauthorized("Invalid username or password.");
        }
    }
}
