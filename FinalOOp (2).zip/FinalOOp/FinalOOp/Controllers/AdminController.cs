﻿using FinalOOp.Model.DTO; // Ensure correct namespace for LoginDto 
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using MySql.Data.MySqlClient;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using System;
using FinalOOp.Model;

namespace FinalOOp.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AdminController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private const string Salt = ")GN#447#^nryrETNwrbR%#&NBRE%#%BBDT#%";

        public AdminController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        private string ConnectionString => _configuration.GetConnectionString("DefaultConnection");

        [HttpPost("Login")]
        public ActionResult Login([FromBody] LoginDto loginDto)
        {
            if (loginDto == null)
                return BadRequest(new { Message = "Invalid login data." });

            string hashedPassword = HashPassword(loginDto.Password);

            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                string query = "SELECT * FROM Admins WHERE Username = @Username AND Password = @Password";

                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Username", loginDto.Username);
                    command.Parameters.AddWithValue("@Password", hashedPassword);

                    using (var reader = command.ExecuteReader())
                    {
                        if (!reader.Read())
                        {
                            return Unauthorized(new { Message = "Invalid login credentials." });
                        }

                        var admin = new Admin
                        {
                            AdminId = Convert.ToInt32(reader["AdminId"]),
                            Username = reader["Username"].ToString(),
                            Email = reader["Email"].ToString(),
                            FirstName = reader["FirstName"].ToString(),
                            LastName = reader["LastName"].ToString(),
                            Role = reader["Role"].ToString()
                        };

                        var token = GenerateJwtToken(admin, loginDto.Platform);
                        return Ok(new
                        {
                            Token = token,
                            Message = "Login successful.",
                            AdminDetails = admin
                        });
                    }
                }
            }
        }

        [HttpPost("Register")]
        public ActionResult Register([FromBody] Admin newAdmin)
        {
            if (newAdmin == null)
                return BadRequest(new { Message = "Invalid admin data." });

            string hashedPassword = HashPassword(newAdmin.Password);

            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();

                string checkQuery = "SELECT COUNT(*) FROM Admins WHERE Email = @Email";
                using (var checkCommand = new MySqlCommand(checkQuery, connection))
                {
                    checkCommand.Parameters.AddWithValue("@Email", newAdmin.Email);

                    var count = Convert.ToInt32(checkCommand.ExecuteScalar());
                    if (count > 0)
                    {
                        return Conflict(new { Message = "Email is already registered. Please choose a different one." });
                    }
                }

                string insertQuery = "INSERT INTO Admins (Username, FirstName, LastName, Email, Password, Role) VALUES (@Username, @FirstName, @LastName, @Email, @Password, @Role)";
                using (var insertCommand = new MySqlCommand(insertQuery, connection))
                {
                    insertCommand.Parameters.AddWithValue("@Username", newAdmin.Username);
                    insertCommand.Parameters.AddWithValue("@FirstName", newAdmin.FirstName);
                    insertCommand.Parameters.AddWithValue("@LastName", newAdmin.LastName);
                    insertCommand.Parameters.AddWithValue("@Email", newAdmin.Email);
                    insertCommand.Parameters.AddWithValue("@Password", hashedPassword);
                    insertCommand.Parameters.AddWithValue("@Role", newAdmin.Role);

                    insertCommand.ExecuteNonQuery();
                }
            }

            return Ok(new { Message = "Registered successfully." });
        }

        [HttpPut("UpdateProfile/{id}")]
        [Authorize(Roles = "admin")]  // Only allow admins to access this endpoint
        public ActionResult UpdateProfile(int id, [FromBody] Admin updatedAdmin)
        {
            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();

                string query = "UPDATE Admins SET Email = @Email" +
                               (string.IsNullOrEmpty(updatedAdmin.Password) ? "" : ", Password = @Password") +
                               ", Role = @Role WHERE AdminId = @AdminId";

                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@Email", updatedAdmin.Email);
                    command.Parameters.AddWithValue("@Role", updatedAdmin.Role); // Update role
                    command.Parameters.AddWithValue("@AdminId", id);

                    if (!string.IsNullOrEmpty(updatedAdmin.Password))
                    {
                        command.Parameters.AddWithValue("@Password", HashPassword(updatedAdmin.Password));
                    }

                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected == 0)
                    {
                        return NotFound("Admin not found.");
                    }
                }
            }

            return Ok("Profile updated successfully.");
        }

        [HttpGet("GetAllAdmins")]
        [Authorize(Roles = "admin")]  // Only allow admins to access this endpoint
        public ActionResult<IEnumerable<Admin>> GetAllAdmins()
        {
            var admins = new List<Admin>();

            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                string query = "SELECT * FROM Admins";

                using (var command = new MySqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        admins.Add(new Admin
                        {
                            AdminId = Convert.ToInt32(reader["AdminId"]),
                            Username = reader["Username"].ToString(),
                            FirstName = reader["FirstName"].ToString(),
                            LastName = reader["LastName"].ToString(),
                            Email = reader["Email"].ToString(),
                            Role = reader["Role"].ToString() // Capture role
                        });
                    }
                }
            }

            return Ok(admins);
        }

        [HttpGet("GetAdmin/{id}")]
        [Authorize(Roles = "admin")]  // Only allow admins to access this endpoint
        public ActionResult<Admin> GetAdmin(int id)
        {
            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                string query = "SELECT * FROM Admins WHERE AdminId = @AdminId";

                using (var command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@AdminId", id);

                    using (var reader = command.ExecuteReader())
                    {
                        if (!reader.Read())
                        {
                            return NotFound("Admin not found.");
                        }

                        var admin = new Admin
                        {
                            AdminId = Convert.ToInt32(reader["AdminId"]),
                            Username = reader["Username"].ToString(),
                            FirstName = reader["FirstName"].ToString(),
                            LastName = reader["LastName"].ToString(),
                            Email = reader["Email"].ToString(),
                            Role = reader["Role"].ToString() // Capture role
                        };

                        return Ok(admin);
                    }
                }
            }
        }

        private string GenerateJwtToken(Admin admin, string platform)
        {
            var claims = new[]
            {
                new Claim(JwtRegisteredClaimNames.Sub, admin.Email),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim("AdminId", admin.AdminId.ToString()),
                new Claim("Roles", admin.Role), // Add role to claims, no validation for admin here
                new Claim("Platform", platform)
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JwtSettings:Key"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                _configuration["JwtSettings:Issuer"],
                _configuration["JwtSettings:Audience"],
                claims,
                expires: DateTime.Now.AddMinutes(Convert.ToDouble(_configuration["JwtSettings:ExpiryMinutes"])),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private string HashPassword(string password)
        {
            using (var sha256 = SHA256.Create())
            {
                var saltedPassword = Salt + password;
                var hashBytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(saltedPassword));
                return BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
            }
        }

        [HttpPost("ProcessOrdersByCustomer/{customerId}")]
        [Authorize(Roles = "admin")]
        public ActionResult ProcessOrdersByCustomer(int customerId)
        {
            using (var connection = new MySqlConnection(ConnectionString))
            {
                connection.Open();
                var transaction = connection.BeginTransaction();
                try
                {
                    string getOrdersQuery = "SELECT OrderId FROM Orders WHERE CustomerId = @CustomerId";
                    using (var getOrdersCommand = new MySqlCommand(getOrdersQuery, connection, transaction))
                    {
                        getOrdersCommand.Parameters.AddWithValue("@CustomerId", customerId);
                        using (var reader = getOrdersCommand.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                int orderId = Convert.ToInt32(reader["OrderId"]);

                                // Process orders logic can be placed here if needed
                                // Example: Update inventory, notify the customer, etc.
                            }
                        }
                    }

                    transaction.Commit();
                    return Ok(new { Message = "Orders processed successfully." });
                }
                catch (Exception)
                {
                    transaction.Rollback();
                    return StatusCode(500, "An error occurred while processing orders.");
                }
            }
        }
    }
}