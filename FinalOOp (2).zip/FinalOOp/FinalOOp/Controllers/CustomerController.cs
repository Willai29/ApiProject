﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using FinalOOp.Model;
using FinalOOp.Model.DTO;
using MySql.Data.MySqlClient;

namespace FinalOOp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CustomerController : ControllerBase
    {
        private readonly IConfiguration _configuration;
        private const string Salt = ")GN#447#^nryrETNwrbR%#&NBRE%#%BBDT#%"; // Define the salt here

        public CustomerController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpPost("Login")]
        public ActionResult Login([FromBody] LoginDto loginDto)
        {
            string hashedPassword = HashPassword(loginDto.Password);
            Customer customer = GetCustomerByUsernameAndPassword(loginDto.Username, hashedPassword);

            if (customer == null)
            {
                return Unauthorized("Invalid login credentials.");
            }

            var token = GenerateJwtToken(customer, loginDto.Platform);
            return Ok(new { Token = token, Message = "Login successful." });
        }

        [HttpPost("Logout")]
        public ActionResult Logout()
        {
            return Ok("Logout successful.");
        }

        [HttpPost("Register")]
        public ActionResult Register([FromBody] Customer newCustomer)
        {
            // Validate required fields
            if (string.IsNullOrWhiteSpace(newCustomer.Username) ||
                string.IsNullOrWhiteSpace(newCustomer.FirstName) ||
                string.IsNullOrWhiteSpace(newCustomer.LastName) ||
                string.IsNullOrWhiteSpace(newCustomer.Email) ||
                string.IsNullOrWhiteSpace(newCustomer.Password) ||
                string.IsNullOrWhiteSpace(newCustomer.Address) ||
                string.IsNullOrWhiteSpace(newCustomer.ContactNumber))
            {
                return BadRequest("All fields are required.");
            }

            // Check if contact number is already registered
            if (IsContactNumberRegistered(newCustomer.ContactNumber))
            {
                return BadRequest("Contact number is already registered. Please choose a different one.");
            }

            // Hash the password
            newCustomer.Password = HashPassword(newCustomer.Password);

            // Set default values
            newCustomer.MemberSince = DateTime.Now;
            newCustomer.Role = "Customer";

            // Insert into the database
            if (InsertCustomer(newCustomer))
            {
                return Ok("Registered successfully.");
            }

            return StatusCode(500, "An error occurred while registering the customer.");
        }

        [HttpPut("UpdateProfile/{id}")]
        public ActionResult UpdateProfile(int id, [FromBody] Customer updatedCustomer)
        {
            var existingCustomer = GetCustomerById(id);
            if (existingCustomer == null)
            {
                return NotFound("Customer not found.");
            }

            if (!string.IsNullOrEmpty(updatedCustomer.Password))
            {
                updatedCustomer.Password = HashPassword(updatedCustomer.Password);
            }

            if (UpdateCustomer(id, updatedCustomer))
            {
                return Ok("Profile updated successfully.");
            }

            return StatusCode(500, "An error occurred while updating the profile.");
        }

        [HttpGet("GetAllCustomers")]
        public ActionResult<IEnumerable<Customer>> GetAllCustomers()
        {
            var customers = GetAllCustomersFromDatabase();
            if (customers == null || !customers.Any())
            {
                return NotFound("No customers found.");
            }

            return Ok(customers);
        }

        [HttpGet("GetCustomer/{id}")]
        public ActionResult<Customer> GetCustomer(int id)
        {
            var customer = GetCustomerById(id);
            if (customer == null)
            {
                return NotFound("Customer not found.");
            }

            return Ok(customer);
        }

        private string GenerateJwtToken(Customer customer, string platform)
        {
            var claims = new[] {
                new Claim(JwtRegisteredClaimNames.Sub, customer.ContactNumber),
                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
                new Claim("CustomerId", customer.CustomerId.ToString()),
                new Claim("Platform", platform),
                 new Claim(ClaimTypes.Role, customer.Role) // Add the role claim
            };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["JwtSettings:Key"]));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                _configuration["JwtSettings:Issuer"],
                _configuration["JwtSettings:Audience"],
                claims,
                expires: DateTime.Now.AddMinutes(30),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private string HashPassword(string password)
        {
            using (var md5 = MD5.Create())
            {
                var saltedPassword = Salt + password;
                var hashBytes = md5.ComputeHash(Encoding.UTF8.GetBytes(saltedPassword));
                return BitConverter.ToString(hashBytes).Replace("-", "").ToLower();
            }
        }

        // Database Helper Methods
        private Customer GetCustomerById(int id)
        {
            using var connection = new MySqlConnection(_configuration.GetConnectionString("DefaultConnection"));
            connection.Open();

            string query = "SELECT * FROM Customers WHERE CustomerId = @CustomerId";
            using var command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@CustomerId", id);

            using var reader = command.ExecuteReader();
            if (reader.Read())
            {
                return MapReaderToCustomer(reader);
            }

            return null;
        }

        private Customer GetCustomerByUsernameAndPassword(string username, string password)
        {
            using var connection = new MySqlConnection(_configuration.GetConnectionString("DefaultConnection"));
            connection.Open();

            string query = "SELECT * FROM Customers WHERE Username = @Username AND Password = @Password";
            using var command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@Username", username);
            command.Parameters.AddWithValue("@Password", password);

            using var reader = command.ExecuteReader();
            if (reader.Read())
            {
                return MapReaderToCustomer(reader);
            }

            return null;
        }

        private IEnumerable<Customer> GetAllCustomersFromDatabase()
        {
            using var connection = new MySqlConnection(_configuration.GetConnectionString("DefaultConnection"));
            connection.Open();

            string query = "SELECT * FROM Customers";
            using var command = new MySqlCommand(query, connection);

            using var reader = command.ExecuteReader();
            var customers = new List<Customer>();
            while (reader.Read())
            {
                customers.Add(MapReaderToCustomer(reader));
            }

            return customers;
        }

        private bool InsertCustomer(Customer customer)
        {
            using var connection = new MySqlConnection(_configuration.GetConnectionString("DefaultConnection"));
            connection.Open();

            string query = "INSERT INTO Customers (Username, FirstName, LastName, Email, Password, ContactNumber, Address, MemberSince, Role) " +
                           "VALUES (@Username, @FirstName, @LastName, @Email, @Password, @ContactNumber, @Address, @MemberSince, @Role)";

            using var command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@Username", customer.Username);
            command.Parameters.AddWithValue("@FirstName", customer.FirstName);
            command.Parameters.AddWithValue("@LastName", customer.LastName);
            command.Parameters.AddWithValue("@Email", customer.Email);
            command.Parameters.AddWithValue("@Password", customer.Password);
            command.Parameters.AddWithValue("@ContactNumber", customer.ContactNumber);
            command.Parameters.AddWithValue("@Address", customer.Address);
            command.Parameters.AddWithValue("@MemberSince", customer.MemberSince);
            command.Parameters.AddWithValue("@Role", customer.Role);

            return command.ExecuteNonQuery() > 0;
        }

        private bool UpdateCustomer(int id, Customer customer)
        {
            using var connection = new MySqlConnection(_configuration.GetConnectionString("DefaultConnection"));
            connection.Open();

            string query = "UPDATE Customers SET FirstName = @FirstName, LastName = @LastName, Email = @Email, " +
                           "Password = @Password, ContactNumber = @ContactNumber, Address = @Address WHERE CustomerId = @CustomerId";

            using var command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@CustomerId", id);
            command.Parameters.AddWithValue("@FirstName", customer.FirstName);
            command.Parameters.AddWithValue("@LastName", customer.LastName);
            command.Parameters.AddWithValue("@Email", customer.Email);
            command.Parameters.AddWithValue("@Password", customer.Password);
            command.Parameters.AddWithValue("@ContactNumber", customer.ContactNumber);
            command.Parameters.AddWithValue("@Address", customer.Address);

            return command.ExecuteNonQuery() > 0;
        }

        private bool IsContactNumberRegistered(string contactNumber)
        {
            using var connection = new MySqlConnection(_configuration.GetConnectionString("DefaultConnection"));
            connection.Open();

            string query = "SELECT COUNT(1) FROM Customers WHERE ContactNumber = @ContactNumber";
            using var command = new MySqlCommand(query, connection);
            command.Parameters.AddWithValue("@ContactNumber", contactNumber); // Updated for string comparison

            return Convert.ToInt32(command.ExecuteScalar()) > 0;
        }

        private Customer MapReaderToCustomer(MySqlDataReader reader)
        {
            return new Customer
            {
                CustomerId = Convert.ToInt32(reader["CustomerId"]),
                Username = reader["Username"].ToString(),
                FirstName = reader["FirstName"].ToString(),
                LastName = reader["LastName"].ToString(),
                Email = reader["Email"].ToString(),
                Password = reader["Password"].ToString(),
                ContactNumber = reader["ContactNumber"].ToString(),
                Address = reader["Address"].ToString(),
                MemberSince = Convert.ToDateTime(reader["MemberSince"]),
                Role = reader["Role"].ToString()
            };
        }
    }
}
